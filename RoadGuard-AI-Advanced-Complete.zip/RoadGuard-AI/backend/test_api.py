from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
r=client.get("/")
assert r.status_code==200
print(r.json())
