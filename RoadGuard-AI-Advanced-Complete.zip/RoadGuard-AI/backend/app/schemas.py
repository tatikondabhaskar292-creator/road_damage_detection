from pydantic import BaseModel, EmailStr, ConfigDict
from typing import Optional
from datetime import datetime

class RegisterIn(BaseModel):
    name: str
    email: EmailStr
    password: str

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class ReportOut(BaseModel):
    id: int
    damage_type: str
    confidence: float
    severity: str
    priority: int
    status: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    image_path: str
    mode: str
    duplicate_of: Optional[int] = None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)
