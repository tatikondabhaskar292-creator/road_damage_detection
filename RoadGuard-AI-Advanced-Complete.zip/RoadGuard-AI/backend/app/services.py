from math import radians, sin, cos, sqrt, atan2
from sqlalchemy.orm import Session
from .models import Report

def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    p1,p2 = radians(lat1), radians(lat2)
    dlat = radians(lat2-lat1)
    dlon = radians(lon2-lon1)
    a = sin(dlat/2)**2 + cos(p1)*cos(p2)*sin(dlon/2)**2
    return 2*R*atan2(sqrt(a), sqrt(1-a))

def find_duplicate(db: Session, damage_type, latitude, longitude, radius_km=0.05):
    if latitude is None or longitude is None:
        return None
    recent = db.query(Report).filter(
        Report.damage_type == damage_type
    ).order_by(Report.created_at.desc()).limit(300).all()
    for item in recent:
        if item.latitude is None or item.longitude is None:
            continue
        if haversine_km(latitude, longitude, item.latitude, item.longitude) <= radius_km:
            return item
    return None

def priority_for(severity, duplicate):
    if duplicate:
        return 4
    return {"critical": 1, "high": 1, "medium": 2, "low": 3}.get(severity, 3)
