from app.database import Base, engine, SessionLocal
from app.models import User
from app.security import hash_password

Base.metadata.create_all(bind=engine)

users = [
    ("Admin","admin@roadguard.local","Admin@123","admin"),
    ("Engineer","engineer@roadguard.local","Engineer@123","engineer"),
    ("Demo User","user@roadguard.local","User@123","user"),
]

db=SessionLocal()
for name,email,password,role in users:
    if not db.query(User).filter(User.email==email).first():
        db.add(User(name=name,email=email,password_hash=hash_password(password),role=role))
db.commit()
db.close()
print("Seed complete.")
