import React, {useEffect, useState} from "react"
import {createRoot} from "react-dom/client"
import {MapContainer, TileLayer, CircleMarker, Popup} from "react-leaflet"
import "leaflet/dist/leaflet.css"
import "./style.css"

const API = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000"

async function api(path, options={}) {
  const token = localStorage.getItem("token")
  const headers = {...(options.headers || {})}
  if (token) headers.Authorization = `Bearer ${token}`
  const res = await fetch(API + path, {...options, headers})
  if (!res.ok) {
    let msg = "Request failed"
    try { const x=await res.json(); msg=x.detail || msg } catch {}
    throw new Error(msg)
  }
  return res.json()
}

function Login({onLogin}) {
  const [email,setEmail]=useState("admin@roadguard.local")
  const [password,setPassword]=useState("Admin@123")
  const [error,setError]=useState("")
  const submit=async e=>{
    e.preventDefault()
    try {
      const x=await api("/auth/login",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({email,password})
      })
      localStorage.setItem("token",x.access_token)
      onLogin()
    } catch(e){setError(e.message)}
  }
  return <div className="login">
    <div className="card login-card">
      <h1>🚧 RoadGuard AI</h1>
      <p>Intelligent Road Monitoring Platform</p>
      <form onSubmit={submit}>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email"/>
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password"/>
        <button>Sign in</button>
      </form>
      {error && <div className="error">{error}</div>}
      <small>Demo: admin@roadguard.local / Admin@123</small>
    </div>
  </div>
}

function App() {
  const [user,setUser]=useState(null)
  const [reports,setReports]=useState([])
  const [dashboard,setDashboard]=useState(null)
  const [file,setFile]=useState(null)
  const [lat,setLat]=useState("")
  const [lon,setLon]=useState("")
  const [message,setMessage]=useState("")
  const [loading,setLoading]=useState(false)

  const load=async()=>{
    try {
      const me=await api("/auth/me"); setUser(me)
      const rs=await api("/reports"); setReports(rs)
      if(me.role!=="user") setDashboard(await api("/dashboard"))
    } catch { localStorage.removeItem("token"); setUser(null) }
  }
  useEffect(()=>{if(localStorage.getItem("token")) load()},[])

  if(!user) return <Login onLogin={load}/>

  const detect=async()=>{
    if(!file) return
    setLoading(true); setMessage("")
    try {
      const fd=new FormData()
      fd.append("image",file)
      if(lat) fd.append("latitude",lat)
      if(lon) fd.append("longitude",lon)
      const x=await api("/reports",{method:"POST",body:fd})
      setMessage(`Detected ${x.count} damage object(s) using ${x.mode.toUpperCase()} mode.`)
      await load()
    } catch(e){setMessage(e.message)}
    finally{setLoading(false)}
  }

  const status=async(id,s)=>{
    const fd=new FormData(); fd.append("status",s)
    await api(`/reports/${id}/status`,{method:"PATCH",body:fd})
    load()
  }

  return <div>
    <header>
      <div><b>🚧 RoadGuard AI</b><span className="badge">{user.role}</span></div>
      <button className="secondary" onClick={()=>{localStorage.removeItem("token");setUser(null)}}>Logout</button>
    </header>

    <main>
      {dashboard && <section className="stats">
        {[
          ["Total",dashboard.total],["Critical",dashboard.critical],
          ["High",dashboard.high],["Medium",dashboard.medium],
          ["Completed",dashboard.completed],["Duplicates",dashboard.duplicates]
        ].map(([a,b])=><div className="stat card" key={a}><small>{a}</small><strong>{b}</strong></div>)}
      </section>}

      <section className="grid">
        <div className="card">
          <h2>🔍 Report Road Damage</h2>
          <input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0])}/>
          <div className="two">
            <input placeholder="Latitude (optional)" value={lat} onChange={e=>setLat(e.target.value)}/>
            <input placeholder="Longitude (optional)" value={lon} onChange={e=>setLon(e.target.value)}/>
          </div>
          <button onClick={detect} disabled={!file||loading}>{loading?"Analyzing...":"Analyze Road"}</button>
          {message && <p className="notice">{message}</p>}
          <p className="muted">If models/best.pt is missing, the backend uses clearly labeled Demo Mode.</p>
        </div>

        <div className="card">
          <h2>🗺️ Damage Map</h2>
          <MapContainer center={[16.5062,80.6480]} zoom={12} style={{height:"330px"}}>
            <TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>
            {reports.filter(r=>r.latitude!=null&&r.longitude!=null).map(r=>
              <CircleMarker key={r.id} center={[r.latitude,r.longitude]} radius={9}>
                <Popup><b>{r.damage_type}</b><br/>Severity: {r.severity}<br/>Status: {r.status}<br/>Confidence: {(r.confidence*100).toFixed(1)}%</Popup>
              </CircleMarker>
            )}
          </MapContainer>
        </div>
      </section>

      <section className="card">
        <div className="row"><h2>📋 Reports</h2>
          {user.role!=="user" && <div>
            <a href={`${API}/reports/export.csv`} target="_blank">CSV</a>{" "}
            <a href={`${API}/reports/export.pdf`} target="_blank">PDF</a>
          </div>}
        </div>
        <div className="table-wrap">
        <table><thead><tr><th>ID</th><th>Damage</th><th>Severity</th><th>Confidence</th><th>Status</th><th>Mode</th><th>Action</th></tr></thead>
        <tbody>{reports.map(r=><tr key={r.id}>
          <td>#{r.id}</td><td>{r.damage_type}</td><td><span className={`sev ${r.severity}`}>{r.severity}</span></td>
          <td>{(r.confidence*100).toFixed(1)}%</td><td>{r.status}</td><td>{r.mode}</td>
          <td>{user.role!=="user" && <select value={r.status} onChange={e=>status(r.id,e.target.value)}>
            {["reported","verified","assigned","repairing","completed"].map(s=><option key={s}>{s}</option>)}
          </select>}</td>
        </tr>)}</tbody></table>
        </div>
      </section>
    </main>
  </div>
}

createRoot(document.getElementById("root")).render(<App/>)
