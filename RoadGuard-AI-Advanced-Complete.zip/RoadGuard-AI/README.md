# RoadGuard AI 🚧

Advanced AI Road Intelligence & Smart Road Monitoring Platform.

## Included in this version

- FastAPI backend
- SQLite database by default (easy local setup)
- JWT authentication
- User/admin/engineer roles
- Road damage reports
- YOLO inference integration when `models/best.pt` exists
- Safe Demo Mode when no trained model exists
- Pothole/crack damage records
- Severity scoring
- GPS latitude/longitude
- Duplicate report detection using distance + damage type
- Repair workflow: reported → verified → assigned → repairing → completed
- Dashboard analytics
- CSV export
- PDF report
- React/Vite frontend
- Interactive Leaflet map
- Docker Compose
- YOLO training/evaluation scripts
- `.env.example`

## Architecture

```text
React + Leaflet
      |
      v
   FastAPI
      |
  +---+------------------+
  |                      |
  v                      v
SQLite/PostgreSQL       AI Engine
  |                   YOLO / Demo
  v                      |
Reports, users,      detections
repairs, locations
```

## Quick start (backend)

Windows:

```cmd
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```

API:
`http://127.0.0.1:8000`

Swagger:
`http://127.0.0.1:8000/docs`

## Seed demo accounts

After installing requirements:

```cmd
python seed.py
```

Demo credentials:

```text
Admin:
admin@roadguard.local
Admin@123

Engineer:
engineer@roadguard.local
Engineer@123

User:
user@roadguard.local
User@123
```

Change these credentials before any real deployment.

## Frontend

Requires Node.js 18+.

```cmd
cd frontend
npm install
npm run dev
```

Open the URL printed by Vite, normally:
`http://localhost:5173`

The frontend expects the API at:
`http://127.0.0.1:8000`

Create `frontend/.env` if needed:

```text
VITE_API_URL=http://127.0.0.1:8000
```

## AI model

The app works in Demo Mode without weights. For real AI inference:

```text
models/best.pt
```

Place your trained YOLO weights there.

Train:

```cmd
cd backend
python train.py
```

Then copy the resulting `best.pt` to `models/best.pt`.

## Dataset

Use a properly licensed road-damage dataset in YOLO format. Do not redistribute datasets unless their license permits it.

## Docker

From the root:

```bash
docker compose up --build
```

Backend: `http://localhost:8000`
Frontend: `http://localhost:5173`

## Important

Demo Mode is not a trained AI model. It is provided so the complete application can be tested before model training. Never report Demo Mode results as model accuracy.

This is an academic/internship project architecture. Production deployment should add HTTPS, secure secrets, PostgreSQL, object storage, rate limiting, stronger password policies, audit logs, and monitoring.
