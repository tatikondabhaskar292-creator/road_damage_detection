from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

def make_report(path, rows, title="RoadGuard AI Report"):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(path), pagesize=A4)
    story = [Paragraph(title, styles["Title"]), Spacer(1, 15)]
    data = [["ID","Damage","Severity","Confidence","Status","Location"]]
    for r in rows:
        loc = f"{r.latitude:.5f}, {r.longitude:.5f}" if r.latitude is not None else "-"
        data.append([
            r.id, r.damage_type, r.severity,
            f"{r.confidence*100:.1f}%", r.status, loc
        ])
    if len(data) == 1:
        data.append(["-","No reports","-","-","-","-"])
    table = Table(data)
    table.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.lightgrey),
        ("GRID",(0,0),(-1,-1),0.5,colors.grey),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
    ]))
    story.append(table)
    doc.build(story)
    return path
