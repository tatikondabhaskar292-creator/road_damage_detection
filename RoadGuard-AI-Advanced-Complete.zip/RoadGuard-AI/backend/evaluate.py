from ultralytics import YOLO
from pathlib import Path

model_path=Path("../models/best.pt")
if not model_path.exists():
    raise FileNotFoundError("Train a model and place it at models/best.pt")
model=YOLO(str(model_path))
print(model.val(data="data.yaml", imgsz=640))
