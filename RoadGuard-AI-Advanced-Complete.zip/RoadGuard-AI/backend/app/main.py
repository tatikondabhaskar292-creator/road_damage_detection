from pathlib import Path
import os, shutil
from fastapi import FastAPI, Depends, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import func
from PIL import Image

from .database import Base, engine, get_db
from .models import User, Report, RepairTask
from .schemas import RegisterIn, LoginIn, TokenOut
from .security import hash_password, verify_password, create_token
from .dependencies import current_user, require_roles
from .ai import detect
from .services import find_duplicate, priority_for
from .reports import make_report

Base.metadata.create_all(bind=engine)

UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "uploads"))
REPORT_DIR = Path(os.getenv("REPORT_DIR", "reports"))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
REPORT_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="RoadGuard AI API", version="1.0.0")

origins = os.getenv(
    "CORS_ORIGINS",
    "http://localhost:5173,http://127.0.0.1:5173"
).split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"name":"RoadGuard AI","status":"running","docs":"/docs"}

@app.post("/auth/register", response_model=TokenOut)
def register(data: RegisterIn, db: Session = Depends(get_db)):
    if len(data.password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")
    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(409, "Email already registered")
    user = User(
        name=data.name,
        email=data.email,
        password_hash=hash_password(data.password),
        role="user",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"access_token": create_token(user.id, user.role), "token_type":"bearer"}

@app.post("/auth/login", response_model=TokenOut)
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return {"access_token": create_token(user.id, user.role), "token_type":"bearer"}

@app.get("/auth/me")
def me(user=Depends(current_user)):
    return {"id":user.id,"name":user.name,"email":user.email,"role":user.role}

@app.post("/reports")
def create_report(
    image: UploadFile = File(...),
    latitude: float | None = Form(default=None),
    longitude: float | None = Form(default=None),
    user=Depends(current_user),
    db: Session = Depends(get_db),
):
    suffix = Path(image.filename or "image.jpg").suffix.lower()
    if suffix not in {".jpg",".jpeg",".png",".webp"}:
        raise HTTPException(400, "Only JPG, JPEG, PNG and WEBP are supported")

    filename = f"{user.id}_{__import__('uuid').uuid4().hex}{suffix}"
    path = UPLOAD_DIR / filename
    with path.open("wb") as f:
        shutil.copyfileobj(image.file, f)

    try:
        pil = Image.open(path).convert("RGB")
    except Exception:
        path.unlink(missing_ok=True)
        raise HTTPException(400, "Invalid image")

    _, detections = detect(pil)

    created = []
    for d in detections:
        duplicate = find_duplicate(
            db, d["damage_type"], latitude, longitude
        )
        report = Report(
            user_id=user.id,
            image_path=str(path),
            latitude=latitude,
            longitude=longitude,
            damage_type=d["damage_type"],
            confidence=d["confidence"],
            severity=d["severity"],
            priority=priority_for(d["severity"], duplicate),
            status="reported",
            mode=d["mode"],
            duplicate_of=duplicate.id if duplicate else None,
        )
        db.add(report)
        db.flush()
        created.append(report)

    db.commit()

    return {
        "mode": detections[0]["mode"] if detections else ("yolo" if Path(os.getenv("MODEL_PATH","../models/best.pt")).exists() else "demo"),
        "count": len(created),
        "reports": [
            {
                "id":r.id,
                "damage_type":r.damage_type,
                "confidence":r.confidence,
                "severity":r.severity,
                "priority":r.priority,
                "duplicate_of":r.duplicate_of,
            } for r in created
        ],
    }

@app.get("/reports")
def list_reports(
    user=Depends(current_user),
    db: Session = Depends(get_db),
):
    q = db.query(Report)
    if user.role == "user":
        q = q.filter(Report.user_id == user.id)
    rows = q.order_by(Report.created_at.desc()).all()
    return [{
        "id":r.id,"damage_type":r.damage_type,"confidence":r.confidence,
        "severity":r.severity,"priority":r.priority,"status":r.status,
        "latitude":r.latitude,"longitude":r.longitude,
        "mode":r.mode,"duplicate_of":r.duplicate_of,
        "created_at":r.created_at.isoformat(),
    } for r in rows]

@app.get("/reports/{report_id}/image")
def report_image(report_id:int, user=Depends(current_user), db:Session=Depends(get_db)):
    r = db.get(Report, report_id)
    if not r:
        raise HTTPException(404,"Report not found")
    if user.role == "user" and r.user_id != user.id:
        raise HTTPException(403,"Forbidden")
    if not Path(r.image_path).exists():
        raise HTTPException(404,"Image not found")
    return FileResponse(r.image_path)

@app.patch("/reports/{report_id}/status")
def update_status(
    report_id:int,
    status:str=Form(...),
    user=Depends(require_roles("admin","engineer")),
    db:Session=Depends(get_db),
):
    allowed={"reported","verified","assigned","repairing","completed"}
    if status not in allowed:
        raise HTTPException(400,f"Status must be one of {sorted(allowed)}")
    r=db.get(Report,report_id)
    if not r: raise HTTPException(404,"Report not found")
    r.status=status
    db.commit()
    return {"id":r.id,"status":r.status}

@app.post("/repairs")
def assign_repair(
    report_id:int=Form(...),
    engineer_id:int=Form(...),
    notes:str=Form(default=""),
    user=Depends(require_roles("admin")),
    db:Session=Depends(get_db),
):
    report=db.get(Report,report_id)
    engineer=db.get(User,engineer_id)
    if not report or not engineer or engineer.role!="engineer":
        raise HTTPException(404,"Report or engineer not found")
    task=RepairTask(report_id=report_id,engineer_id=engineer_id,notes=notes)
    report.status="assigned"
    db.add(task); db.commit(); db.refresh(task)
    return {"id":task.id,"report_id":task.report_id,"engineer_id":task.engineer_id}

@app.get("/dashboard")
def dashboard(user=Depends(require_roles("admin","engineer")), db:Session=Depends(get_db)):
    rows=db.query(Report).all()
    return {
        "total":len(rows),
        "critical":sum(r.severity=="critical" for r in rows),
        "high":sum(r.severity=="high" for r in rows),
        "medium":sum(r.severity=="medium" for r in rows),
        "low":sum(r.severity=="low" for r in rows),
        "reported":sum(r.status=="reported" for r in rows),
        "repairing":sum(r.status=="repairing" for r in rows),
        "completed":sum(r.status=="completed" for r in rows),
        "duplicates":sum(r.duplicate_of is not None for r in rows),
    }

@app.get("/engineers")
def engineers(user=Depends(require_roles("admin")), db:Session=Depends(get_db)):
    users=db.query(User).filter(User.role=="engineer").all()
    return [{"id":u.id,"name":u.name,"email":u.email} for u in users]

@app.get("/reports/export.csv")
def export_csv(user=Depends(require_roles("admin","engineer")), db:Session=Depends(get_db)):
    import csv
    import tempfile
    rows=db.query(Report).order_by(Report.created_at.desc()).all()
    path=REPORT_DIR/"road_reports.csv"
    with path.open("w",newline="",encoding="utf-8") as f:
        writer=csv.writer(f)
        writer.writerow(["id","damage","confidence","severity","priority","status","lat","lon","mode","created_at"])
        for r in rows:
            writer.writerow([r.id,r.damage_type,r.confidence,r.severity,r.priority,r.status,r.latitude,r.longitude,r.mode,r.created_at])
    return FileResponse(path,filename="road_reports.csv",media_type="text/csv")

@app.get("/reports/export.pdf")
def export_pdf(user=Depends(require_roles("admin","engineer")), db:Session=Depends(get_db)):
    rows=db.query(Report).order_by(Report.created_at.desc()).all()
    path=make_report(REPORT_DIR/"road_reports.pdf", rows)
    return FileResponse(path,filename="road_reports.pdf",media_type="application/pdf")
