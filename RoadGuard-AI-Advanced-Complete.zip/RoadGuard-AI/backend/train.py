from ultralytics import YOLO

# Put your YOLO dataset configuration in data.yaml.
# Recommended classes:
# 0 longitudinal_crack
# 1 transverse_crack
# 2 alligator_crack
# 3 pothole

model = YOLO("yolo11n.pt")
model.train(
    data="data.yaml",
    epochs=50,
    imgsz=640,
    batch=8,
    project="runs/detect",
    name="roadguard",
    patience=15,
)
