from pathlib import Path
import os
import cv2
import numpy as np
from PIL import Image

MODEL_PATH = Path(os.getenv("MODEL_PATH", "../models/best.pt"))

def severity_for(damage, confidence, bbox, image_size):
    x1, y1, x2, y2 = bbox
    w, h = image_size
    area_ratio = max(0.0, ((x2-x1)*(y2-y1)) / max(w*h, 1))
    score = confidence * 0.65 + min(area_ratio * 5, 1.0) * 0.35
    if damage.lower() in {"pothole", "alligator_crack"} and score >= 0.60:
        return "critical"
    if score >= 0.72:
        return "high"
    if score >= 0.45:
        return "medium"
    return "low"

def run_yolo(image):
    from ultralytics import YOLO
    model = YOLO(str(MODEL_PATH))
    result = model.predict(source=np.array(image), conf=0.25, verbose=False)[0]
    detections = []
    for box in result.boxes:
        cls = int(box.cls[0])
        conf = float(box.conf[0])
        bbox = list(map(int, box.xyxy[0].tolist()))
        name = result.names[cls]
        detections.append({
            "damage_type": name,
            "confidence": conf,
            "bbox": bbox,
            "severity": severity_for(name, conf, bbox, image.size),
            "mode": "yolo",
        })
    return result.plot()[:, :, ::-1], detections

def demo_detect(image):
    arr = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(cv2.GaussianBlur(gray, (7,7), 0), 60, 150)
    mask = cv2.dilate(edges, np.ones((7,7), np.uint8), iterations=2)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    h, w = gray.shape
    detections = []
    candidates = []
    for c in contours:
        x,y,cw,ch = cv2.boundingRect(c)
        area = cw*ch
        if area < max(500, w*h*0.002) or cw < 25 or ch < 15 or area > w*h*0.35:
            continue
        candidates.append((x,y,cw,ch,area))
    for x,y,cw,ch,area in sorted(candidates, key=lambda z:z[4], reverse=True)[:5]:
        damage = "pothole" if 0.5 <= cw/max(ch,1) <= 2.8 else "longitudinal_crack"
        conf = min(0.55 + (area/(w*h))*2.0, 0.88)
        bbox = [x,y,x+cw,y+ch]
        detections.append({
            "damage_type": damage,
            "confidence": float(conf),
            "bbox": bbox,
            "severity": severity_for(damage, conf, bbox, (w,h)),
            "mode": "demo",
        })
        cv2.rectangle(arr,(x,y),(x+cw,y+ch),(0,255,0),3)
        cv2.putText(arr,f"{damage} {conf*100:.1f}%",(x,max(25,y-8)),
                    cv2.FONT_HERSHEY_SIMPLEX,0.65,(0,255,0),2)
    return cv2.cvtColor(arr, cv2.COLOR_BGR2RGB), detections

def detect(image):
    if MODEL_PATH.exists():
        return run_yolo(image)
    return demo_detect(image)
