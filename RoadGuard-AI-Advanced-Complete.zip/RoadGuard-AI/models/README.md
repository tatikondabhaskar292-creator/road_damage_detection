Place a trained YOLO model here as `best.pt`.

The backend automatically uses it when available. Otherwise Demo Mode is used.
